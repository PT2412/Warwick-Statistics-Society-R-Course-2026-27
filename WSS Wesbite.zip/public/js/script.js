/* ============================================================
   WARWICK STATISTICS SOCIETY — site scripts
   No frameworks, no build step — just vanilla JS.
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  initHeaderScroll();
  initMobileNav();
  initActiveNavLink();
  initRevealOnScroll();
  initStatCounters();
  initEventFilters();
  initContactForm();
  initFooterYear();
});

/* ---------- Sticky header shadow ---------- */
function initHeaderScroll() {
  const header = document.getElementById('siteHeader');
  if (!header) return;
  const onScroll = () => {
    header.classList.toggle('is-scrolled', window.scrollY > 8);
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });
}

/* ---------- Mobile nav toggle ---------- */
function initMobileNav() {
  const header = document.getElementById('siteHeader');
  const toggle = document.getElementById('navToggle');
  if (!header || !toggle) return;

  const closeNav = () => {
    header.classList.remove('nav-open');
    toggle.setAttribute('aria-expanded', 'false');
  };

  toggle.addEventListener('click', () => {
    const isOpen = header.classList.toggle('nav-open');
    toggle.setAttribute('aria-expanded', String(isOpen));
  });

  // Close menu when a nav link is tapped, or when resizing back to desktop
  header.querySelectorAll('.main-nav a').forEach((link) => {
    link.addEventListener('click', closeNav);
  });
  window.addEventListener('resize', () => {
    if (window.innerWidth > 900) closeNav();
  });
}

/* ---------- Highlight current page in nav ---------- */
function initActiveNavLink() {
  const links = document.querySelectorAll('.main-nav a');
  const norm = (p) => (p.replace(/\/index\.html$/, '/').replace(/\.html$/, '').replace(/\/+$/, '') || '/');
  const current = norm(window.location.pathname);

  links.forEach((link) => {
    const href = link.getAttribute('href');
    if (href && href.startsWith('/') && norm(href) === current) {
      link.classList.add('is-active');
    }
  });
}

/* ---------- Scroll reveal (IntersectionObserver) ---------- */
function initRevealOnScroll() {
  const targets = document.querySelectorAll('.reveal');
  if (!targets.length) return;

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    targets.forEach((el) => el.classList.add('is-visible'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });

  targets.forEach((el) => observer.observe(el));
}

/* ---------- Animated stat counters in the hero ---------- */
function initStatCounters() {
  const stats = document.querySelectorAll('[data-count-to]');
  if (!stats.length) return;

  const animate = (el) => {
    const target = parseInt(el.getAttribute('data-count-to'), 10);
    const suffix = el.getAttribute('data-suffix') || '';
    const duration = 1200;
    const start = performance.now();

    const step = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      el.textContent = Math.round(eased * target) + suffix;
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    stats.forEach((el) => {
      el.textContent = el.getAttribute('data-count-to') + (el.getAttribute('data-suffix') || '');
    });
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        animate(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.6 });

  stats.forEach((el) => observer.observe(el));
}

/* ---------- Events page: category filtering ---------- */
function initEventFilters() {
  const filterBar = document.querySelector('[data-filter-bar]');
  const cards = document.querySelectorAll('[data-category]');
  const emptyState = document.querySelector('[data-empty-state]');
  if (!filterBar || !cards.length) return;

  filterBar.addEventListener('click', (e) => {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;

    filterBar.querySelectorAll('.filter-btn').forEach((b) => b.classList.remove('is-active'));
    btn.classList.add('is-active');

    const filter = btn.getAttribute('data-filter');
    let visibleCount = 0;

    cards.forEach((card) => {
      const match = filter === 'all' || card.getAttribute('data-category') === filter;
      card.hidden = !match;
      if (match) visibleCount += 1;
    });

    if (emptyState) emptyState.hidden = visibleCount !== 0;
  });
}

/* ---------- Contact form: client-side validation + friendly confirmation ----------
   This is a static site with no backend, so the form does not actually send email
   yet. Wire the <form id="contactForm"> action up to a form service such as
   Formspree, Netlify Forms, or EmailJS to receive real submissions — see the
   comment in contact.html for exactly where to make that change. */
function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;
  const statusBox = document.getElementById('formStatus');

  const validators = {
    name: (v) => v.trim().length > 1 || 'Please enter your name.',
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) || 'Please enter a valid email address.',
    message: (v) => v.trim().length > 9 || 'Tell us a little more (10+ characters).',
  };

  const showError = (field, message) => {
    const wrap = field.closest('.form-field');
    const errorEl = wrap.querySelector('.field-error');
    wrap.classList.toggle('has-error', Boolean(message));
    if (errorEl) errorEl.textContent = message || '';
  };

  form.querySelectorAll('input, textarea, select').forEach((field) => {
    field.addEventListener('blur', () => {
      const rule = validators[field.name];
      if (!rule) return;
      const result = rule(field.value);
      showError(field, result === true ? '' : result);
    });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let firstInvalid = null;

    Object.keys(validators).forEach((name) => {
      const field = form.elements[name];
      if (!field) return;
      const result = validators[name](field.value);
      showError(field, result === true ? '' : result);
      if (result !== true && !firstInvalid) firstInvalid = field;
    });

    if (firstInvalid) {
      firstInvalid.focus();
      if (statusBox) statusBox.classList.remove('is-visible');
      return;
    }

    // No backend is connected — simulate a successful hand-off so the
    // interaction feels complete while editing locally in the browser.
    if (statusBox) {
      statusBox.classList.add('is-visible');
      statusBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    form.reset();
  });
}

/* ---------- Footer year ---------- */
function initFooterYear() {
  const el = document.getElementById('year');
  if (el) el.textContent = new Date().getFullYear();
}
