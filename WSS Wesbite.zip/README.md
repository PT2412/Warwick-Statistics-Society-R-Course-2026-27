# Warwick Statistics Society — website

Wix-managed Astro site (server-rendered on Wix hosting). Pages live in `src/pages/`, the
original stylesheet/script/images in `public/`.

## Live events from Notion

`/events` and the home-page "Upcoming events" preview are rendered on each request from a
Notion database (cached for 60 seconds), via `src/lib/notion.ts`. The Notion token stays on
the server. Only events starting in the next 14 days are listed (set `EVENTS_WINDOW_DAYS` to
change this); rows with no Date are treated as recurring and always shown.

Database columns (names are case-insensitive):

| Column | Notion type | Notes |
|---|---|---|
| Name | Title | Event title (rows with no name are skipped) |
| Date | Date | Sorting, the "Tue 3 Feb" label, and the 2-week window. Include a time to show it on the card. |
| Tags | Multi-select | Academic / careers / Department / Social / Sports event, Other. The first tag sets the card colour and filter; any new tag gets its own filter button automatically. Untagged rows show as Other. |
| Location | Text | e.g. `OC1.04` |
| Description | Text | One or two sentences (optional) |
| Push to Site | Select (Yes / No) | Only rows set to **Yes** appear. Blank or No = hidden. |
| Time, Date label | Text | Optional extras: Time overrides the time from Date; Date label overrides the date shown (e.g. `Every Wed`). |

Setup (once):
1. https://www.notion.so/profile/integrations → New internal integration → copy the token.
2. Open the events database in Notion → `•••` → Connections → add the integration.
3. Copy the database ID (the 32-character part of the database URL).
4. In this project folder: `npx wix login`, then
   `npx wix env set --key=NOTION_TOKEN --value=<token>` and
   `npx wix env set --key=NOTION_DATABASE_ID --value=<database id>`, then `npx wix build && npx wix release`.
