// Live events from a Notion database. Runs on the server only; the token never reaches the browser.
import { NOTION_TOKEN, NOTION_DATABASE_ID, EVENTS_WINDOW_DAYS } from "astro:env/server";

export interface SiteEvent {
  id: string;
  title: string;
  description: string;
  category: string; // filter slug, from the Tags column: academic | careers | department | social | sports | other | …
  categoryLabel: string;
  tagClass: string; // CSS class for the coloured tag
  dateLabel: string;
  sortKey: number; // ms since epoch; Infinity for undated/recurring (listed first via -1)
  location: string;
  time: string;
}

export type EventsResult =
  | { status: "ok"; events: SiteEvent[] }
  | { status: "not-configured"; events: [] }
  | { status: "error"; events: SiteEvent[]; message: string };

const NOTION_VERSION = "2022-06-28";

// Only events starting within this many days are shown. Rows with no date (e.g. "Every Wed")
// are treated as recurring and always shown; set Push to Site to No to hide one.
export const WINDOW_DAYS = Math.max(1, Math.round(Number(EVENTS_WINDOW_DAYS) || 14));
export const windowLabel = (days = WINDOW_DAYS) =>
  days % 7 === 0 ? (days === 7 ? "week" : `${days / 7} weeks`) : days === 1 ? "day" : `${days} days`;
const CACHE_MS = 60_000;
let cache: { at: number; events: SiteEvent[] } | null = null;

type Prop = { type: string; [k: string]: any };

const plain = (arr: any[] | undefined) => (arr ?? []).map((t) => t.plain_text ?? "").join("").trim();

function textOf(p: Prop | undefined): string {
  if (!p) return "";
  switch (p.type) {
    case "title": return plain(p.title);
    case "rich_text": return plain(p.rich_text);
    case "select": return p.select?.name ?? "";
    case "status": return p.status?.name ?? "";
    case "multi_select": return (p.multi_select ?? []).map((s: any) => s.name).join(", ");
    case "url": return p.url ?? "";
    case "number": return p.number == null ? "" : String(p.number);
    case "formula": return p.formula?.string ?? "";
    default: return "";
  }
}

// Find a property by (case-insensitive) name candidates, optionally restricted to types.
function find(props: Record<string, Prop>, names: string[], types?: string[]): Prop | undefined {
  const lower = Object.fromEntries(Object.entries(props).map(([k, v]) => [k.trim().toLowerCase(), v]));
  for (const n of names) {
    const p = lower[n];
    if (p && (!types || types.includes(p.type))) return p;
  }
  return undefined;
}

const TZ = "Europe/London";
const dayFmt = new Intl.DateTimeFormat("en-GB", { weekday: "short", day: "numeric", month: "short", timeZone: TZ });
const timeFmt = new Intl.DateTimeFormat("en-GB", { hour: "numeric", minute: "2-digit", hour12: true, timeZone: TZ });
const ymd = (d: Date) => new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(d);

function fmtTime(d: Date): string {
  return timeFmt.format(d).replace(/\s/g, "").toLowerCase();
}

// Notion Tags → site categories. "Academic event" → academic, "careers event" → careers, etc.
// Any other tag still works: it gets its own filter button and a neutral colour.
const KNOWN: Record<string, { slug: string; label: string }> = {
  academic: { slug: "academic", label: "Academic" },
  career: { slug: "careers", label: "Careers" },
  careers: { slug: "careers", label: "Careers" },
  department: { slug: "department", label: "Department" },
  social: { slug: "social", label: "Social" },
  socials: { slug: "social", label: "Social" },
  sport: { slug: "sports", label: "Sports" },
  sports: { slug: "sports", label: "Sports" },
  competition: { slug: "competitions", label: "Competitions" },
  competitions: { slug: "competitions", label: "Competitions" },
  other: { slug: "other", label: "Other" },
};
const STYLED = new Set(["academic", "careers", "department", "social", "sports", "competitions", "other"]);
// Order of the filter buttons on /events.
const ORDER = ["academic", "careers", "department", "social", "sports", "competitions"];

function categoryOf(tags: string[]): { slug: string; label: string } {
  const parsed = tags.map((raw) => {
    const base = raw.toLowerCase().replace(/\s+events?$/, "").trim();
    const known = KNOWN[base];
    if (known) return known;
    const slug = base.replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    return slug ? { slug, label: base.charAt(0).toUpperCase() + base.slice(1) } : null;
  }).filter(Boolean) as { slug: string; label: string }[];
  // Prefer a recognised category if an event has several tags.
  return parsed.find((c) => STYLED.has(c.slug) && c.slug !== "other") ?? parsed[0] ?? KNOWN.other;
}

export function categoriesOf(events: SiteEvent[]): { slug: string; label: string }[] {
  const seen = new Map<string, string>();
  for (const e of events) if (!seen.has(e.category)) seen.set(e.category, e.categoryLabel);
  const rank = (slug: string) => (slug === "other" ? 999 : ORDER.indexOf(slug) === -1 ? 500 : ORDER.indexOf(slug));
  return [...seen].map(([slug, label]) => ({ slug, label }))
    .sort((a, b) => rank(a.slug) - rank(b.slug) || a.label.localeCompare(b.label));
}

// "Push to Site" (Yes/No select). Only rows set to Yes appear; blank or No are hidden.
function isPublished(p: Prop): boolean {
  if (p.type === "checkbox") return !!p.checkbox;
  if (p.type === "formula") return p.formula?.boolean ?? /^(yes|true)$/i.test(p.formula?.string ?? "");
  return /^(yes|y|true|published|live|show)$/i.test(textOf(p).trim());
}

function toEvent(page: any): SiteEvent | null {
  const props: Record<string, Prop> = page.properties ?? {};

  const published = find(props, ["push to site", "published", "publish", "show on site", "visible", "live"],
    ["checkbox", "select", "status", "formula"]);
  if (published && !isPublished(published)) return null;

  const titleProp = Object.values(props).find((p) => p.type === "title");
  const title = textOf(titleProp);
  if (!title) return null;

  const dateProp = find(props, ["date", "when", "event date"], ["date"]) ?? Object.values(props).find((p) => p.type === "date");
  const start: string | undefined = dateProp?.date?.start;
  const end: string | undefined = dateProp?.date?.end ?? undefined;
  const hasTimePart = !!start && start.includes("T");
  const startDate = start ? new Date(start) : null;

  // Upcoming only: drop events that ended before today, or start after the window (London dates).
  if (startDate) {
    const now = new Date();
    const last = end ? new Date(end) : startDate;
    if (ymd(last) < ymd(now)) return null;
    const horizon = new Date(now.getTime() + WINDOW_DAYS * 86_400_000);
    if (ymd(startDate) > ymd(horizon)) return null;
  }

  const labelOverride = textOf(find(props, ["date label", "when label", "display date", "schedule"], ["rich_text", "select", "formula"]));
  const dateLabel = labelOverride || (startDate ? dayFmt.format(startDate).replace(",", "") : "Date TBC");

  const timeText = textOf(find(props, ["time", "times"], ["rich_text", "select", "formula"]));
  const time = timeText || (startDate && hasTimePart ? fmtTime(startDate) : "");

  const location = textOf(find(props, ["location", "venue", "room", "where"], ["rich_text", "select", "formula"]));
  const description = textOf(find(props, ["description", "summary", "about", "details"], ["rich_text"]));

  const tagProp = find(props, ["tags", "tag", "category", "categories", "type"], ["multi_select", "select", "status"]);
  const tags: string[] =
    tagProp?.type === "multi_select" ? (tagProp.multi_select ?? []).map((t: any) => t.name)
    : tagProp ? [textOf(tagProp)].filter(Boolean) : [];
  const { slug: category, label: categoryLabel } = categoryOf(tags);
  const tagClass = `tag--${STYLED.has(category) ? category : "other"}`;

  return {
    id: page.id,
    title,
    description,
    category,
    categoryLabel,
    tagClass,
    dateLabel,
    sortKey: startDate ? startDate.getTime() : -1, // undated/recurring first
    location,
    time,
  };
}

const notion = async (path: string, body?: unknown) => {
  const res = await fetch(`https://api.notion.com/v1/${path}`, {
    method: body ? "POST" : "GET",
    headers: {
      Authorization: `Bearer ${NOTION_TOKEN}`,
      "Notion-Version": NOTION_VERSION,
      ...(body ? { "Content-Type": "application/json" } : {}),
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  if (!res.ok) throw new Error(`Notion ${res.status}: ${(await res.text()).slice(0, 200)}`);
  return res.json() as Promise<any>;
};

async function fetchAll(): Promise<SiteEvent[]> {
  // Ask Notion only for rows dated from a month ago onwards (or undated), so old events never
  // push new ones past the page limit as the database grows. Exact filtering happens in toEvent.
  const db = await notion(`databases/${NOTION_DATABASE_ID}`);
  const props: Record<string, Prop & { name?: string }> = db.properties ?? {};
  const dateName =
    Object.entries(props).find(([k, v]) => v.type === "date" && ["date", "when", "event date"].includes(k.trim().toLowerCase()))?.[0] ??
    Object.entries(props).find(([, v]) => v.type === "date")?.[0];
  const since = ymd(new Date(Date.now() - 31 * 86_400_000));
  const query: Record<string, unknown> = { page_size: 100 };
  if (dateName) {
    query.filter = { or: [
      { property: dateName, date: { on_or_after: since } },
      { property: dateName, date: { is_empty: true } },
    ] };
    query.sorts = [{ property: dateName, direction: "ascending" }];
  }

  const out: SiteEvent[] = [];
  let cursor: string | undefined;
  for (let i = 0; i < 5; i++) {
    const data = await notion(`databases/${NOTION_DATABASE_ID}/query`, { ...query, ...(cursor ? { start_cursor: cursor } : {}) });
    for (const page of data.results ?? []) {
      const ev = toEvent(page);
      if (ev) out.push(ev);
    }
    if (!data.has_more) break;
    cursor = data.next_cursor;
  }
  return out.sort((a, b) => a.sortKey - b.sortKey);
}

export async function getEvents(): Promise<EventsResult> {
  if (!NOTION_TOKEN || !NOTION_DATABASE_ID) return { status: "not-configured", events: [] };
  if (cache && Date.now() - cache.at < CACHE_MS) return { status: "ok", events: cache.events };
  try {
    const events = await fetchAll();
    cache = { at: Date.now(), events };
    return { status: "ok", events };
  } catch (e: any) {
    console.error("[events] Notion fetch failed:", e?.message ?? e);
    // Serve the last good copy if we have one, but say so.
    return { status: "error", events: cache?.events ?? [], message: String(e?.message ?? e) };
  }
}
