// @ts-check
import { defineConfig, envField } from 'astro/config';
import wix from "@wix/astro";
import wixPages from "@wix/astro-pages";

import react from "@astrojs/react";
import wixHostingAdapter from "@wix/astro-wix-hosting-adapter";

// https://astro.build/config
export default defineConfig({
  integrations: [wix(), wixPages(), react()],
  security: { checkOrigin: false },
  adapter: wixHostingAdapter(),

  image: {
    domains: ["static.wixstatic.com"],
  },

  output: "server",

  // Notion connection for the live events list. Set with the Wix CLI:
  //   npx wix env set --key=NOTION_TOKEN --value=<internal integration token>
  //   npx wix env set --key=NOTION_DATABASE_ID --value=<events database id>
  // Optional: npx wix env set --key=EVENTS_WINDOW_DAYS --value=14
  env: {
    schema: {
      NOTION_TOKEN: envField.string({ context: "server", access: "secret", optional: true }),
      NOTION_DATABASE_ID: envField.string({ context: "server", access: "public", optional: true }),
      // How far ahead the events list looks, in days.
      EVENTS_WINDOW_DAYS: envField.number({ context: "server", access: "public", default: 14 }),
    },
  },
});
